import 'package:flutter/material.dart';

var bluecolor=Color(0xff575DFF);
